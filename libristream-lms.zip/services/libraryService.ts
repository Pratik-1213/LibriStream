import { Book, Member, Transaction, TransactionStatus, DashboardStats } from '../types';

/**
 * SIMULATED BACKEND SERVICE
 * 
 * Since this is a frontend-only environment, this service acts as the NestJS Controller + Service + Database layer.
 * It persists data to localStorage to maintain state across reloads.
 */

const STORAGE_KEYS = {
  BOOKS: 'lms_books',
  MEMBERS: 'lms_members',
  TRANSACTIONS: 'lms_transactions',
};

// Initial Seed Data
const seedBooks: Book[] = [
  { _id: '1', title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', isbn: '9780743273565', category: 'Fiction', stock_quantity: 5, available_quantity: 5 },
  { _id: '2', title: 'Clean Code', author: 'Robert C. Martin', isbn: '9780132350884', category: 'Technology', stock_quantity: 3, available_quantity: 3 },
  { _id: '3', title: '1984', author: 'George Orwell', isbn: '9780451524935', category: 'Fiction', stock_quantity: 10, available_quantity: 8 }, // Simulated 2 checked out
];

const seedMembers: Member[] = [
  { _id: '1', name: 'Alice Johnson', email: 'alice@example.com', joined_date: '2023-01-15' },
  { _id: '2', name: 'Bob Smith', email: 'bob@example.com', joined_date: '2023-03-22' },
];

// Helper to simulate delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

class LibraryService {
  private get<T>(key: string, seed: T): T {
    const stored = localStorage.getItem(key);
    if (!stored) {
      localStorage.setItem(key, JSON.stringify(seed));
      return seed;
    }
    return JSON.parse(stored);
  }

  private save(key: string, data: any) {
    localStorage.setItem(key, JSON.stringify(data));
  }

  // --- Books ---
  async getBooks(): Promise<Book[]> {
    await delay(300);
    return this.get<Book[]>(STORAGE_KEYS.BOOKS, seedBooks);
  }

  async addBook(book: Omit<Book, '_id' | 'available_quantity'>): Promise<Book> {
    await delay(300);
    const books = this.get<Book[]>(STORAGE_KEYS.BOOKS, seedBooks);
    const newBook: Book = {
      ...book,
      _id: Math.random().toString(36).substr(2, 9),
      available_quantity: book.stock_quantity, // Initial available equals stock
    };
    books.push(newBook);
    this.save(STORAGE_KEYS.BOOKS, books);
    return newBook;
  }

  // --- Members ---
  async getMembers(): Promise<Member[]> {
    await delay(300);
    return this.get<Member[]>(STORAGE_KEYS.MEMBERS, seedMembers);
  }

  async addMember(member: Omit<Member, '_id' | 'joined_date'>): Promise<Member> {
    await delay(300);
    const members = this.get<Member[]>(STORAGE_KEYS.MEMBERS, seedMembers);
    const newMember: Member = {
      ...member,
      _id: Math.random().toString(36).substr(2, 9),
      joined_date: new Date().toISOString(),
    };
    members.push(newMember);
    this.save(STORAGE_KEYS.MEMBERS, members);
    return newMember;
  }

  // --- Transactions (The Core Business Logic) ---

  async getTransactions(): Promise<Transaction[]> {
    await delay(300);
    const transactions = this.get<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    const books = this.get<Book[]>(STORAGE_KEYS.BOOKS, seedBooks);
    const members = this.get<Member[]>(STORAGE_KEYS.MEMBERS, seedMembers);

    // Populate data for UI
    return transactions.map(t => ({
      ...t,
      book_details: books.find(b => b._id === t.book_id),
      member_details: members.find(m => m._id === t.member_id),
    }));
  }

  /**
   * BUSINESS LOGIC: Issue Book
   * 1. Verify available_quantity > 0
   * 2. Decrement available_quantity
   * 3. Create transaction with Status 'Issued'
   */
  async issueBook(bookId: string, memberId: string): Promise<Transaction> {
    await delay(400);
    const books = this.get<Book[]>(STORAGE_KEYS.BOOKS, seedBooks);
    const bookIndex = books.findIndex(b => b._id === bookId);

    if (bookIndex === -1) throw new Error('Book not found');
    
    const book = books[bookIndex];

    if (book.available_quantity <= 0) {
      throw new Error('Book is not available for issue');
    }

    // Decrement availability
    book.available_quantity -= 1;
    books[bookIndex] = book;
    this.save(STORAGE_KEYS.BOOKS, books);

    // Create Transaction
    const transactions = this.get<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    const newTransaction: Transaction = {
      _id: Math.random().toString(36).substr(2, 9),
      book_id: bookId,
      member_id: memberId,
      issue_date: new Date().toISOString(),
      return_date: null,
      status: TransactionStatus.Issued
    };
    
    transactions.push(newTransaction);
    this.save(STORAGE_KEYS.TRANSACTIONS, transactions);

    return newTransaction;
  }

  /**
   * BUSINESS LOGIC: Return Book
   * 1. Find active transaction
   * 2. Mark as 'Returned'
   * 3. Set return_date
   * 4. Increment available_quantity
   */
  async returnBook(transactionId: string): Promise<void> {
    await delay(400);
    const transactions = this.get<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    const txIndex = transactions.findIndex(t => t._id === transactionId);

    if (txIndex === -1) throw new Error('Transaction not found');
    const tx = transactions[txIndex];

    if (tx.status === TransactionStatus.Returned) {
      throw new Error('Book already returned');
    }

    // Update Transaction
    tx.status = TransactionStatus.Returned;
    tx.return_date = new Date().toISOString();
    transactions[txIndex] = tx;
    this.save(STORAGE_KEYS.TRANSACTIONS, transactions);

    // Increment Book Availability
    const books = this.get<Book[]>(STORAGE_KEYS.BOOKS, seedBooks);
    const bookIndex = books.findIndex(b => b._id === tx.book_id);
    if (bookIndex !== -1) {
      books[bookIndex].available_quantity += 1;
      this.save(STORAGE_KEYS.BOOKS, books);
    }
  }

  // --- Dashboard ---
  async getDashboardStats(): Promise<DashboardStats> {
    await delay(300);
    const books = this.get<Book[]>(STORAGE_KEYS.BOOKS, seedBooks);
    const members = this.get<Member[]>(STORAGE_KEYS.MEMBERS, seedMembers);
    const transactions = this.get<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    const activeLoans = transactions.filter(t => t.status === TransactionStatus.Issued).length;

    return {
      totalBooks: books.reduce((acc, curr) => acc + curr.stock_quantity, 0),
      activeMembers: members.length,
      activeLoans
    };
  }
}

export const libraryService = new LibraryService();
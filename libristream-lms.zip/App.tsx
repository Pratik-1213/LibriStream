import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { BooksManager } from './components/BooksManager';
import { MemberManager } from './components/MemberManager';
import { CirculationDesk } from './components/CirculationDesk';

const App: React.FC = () => {
  // Simple state-based routing
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'books':
        return <BooksManager />;
      case 'members':
        return <MemberManager />;
      case 'circulation':
        return <CirculationDesk />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </Layout>
  );
};

export default App;
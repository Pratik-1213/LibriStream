import React, { useEffect, useState } from 'react';
import { libraryService } from '../services/libraryService';
import { DashboardStats } from '../types';
import { BookOpen, Users, Activity } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await libraryService.getDashboardStats();
        setStats(data);
      } catch (error) {
        console.error("Failed to load stats", error);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <div className="p-4 text-gray-500">Loading dashboard analytics...</div>;
  if (!stats) return <div className="p-4 text-red-500">Error loading data.</div>;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">System Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Total Books Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Total Books in Stock</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-2">{stats.totalBooks}</h3>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
            <BookOpen className="w-6 h-6" />
          </div>
        </div>

        {/* Active Members Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Active Members</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-2">{stats.activeMembers}</h3>
          </div>
          <div className="p-3 bg-green-50 text-green-600 rounded-lg">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Active Loans Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Active Loans</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-2">{stats.activeLoans}</h3>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <Activity className="w-6 h-6" />
          </div>
        </div>
      </div>

      <div className="mt-8 bg-indigo-900 rounded-xl p-8 text-white">
        <h3 className="text-xl font-bold mb-2">Welcome to LibriStream</h3>
        <p className="text-indigo-200">
          Manage your library inventory, track member activity, and handle book circulation efficiently. 
          Use the navigation menu on the left to access different modules.
        </p>
      </div>
    </div>
  );
};
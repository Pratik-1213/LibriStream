import React, { useEffect, useState } from 'react';
import { libraryService } from '../services/libraryService';
import { Book, Member, Transaction, TransactionStatus } from '../types';
import { ArrowRightLeft, CheckCircle, AlertCircle } from 'lucide-react';

export const CirculationDesk: React.FC = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  const [selectedBook, setSelectedBook] = useState('');
  const [selectedMember, setSelectedMember] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    try {
      const [b, m, t] = await Promise.all([
        libraryService.getBooks(),
        libraryService.getMembers(),
        libraryService.getTransactions()
      ]);
      setBooks(b);
      setMembers(m);
      setTransactions(t.sort((a, b) => new Date(b.issue_date).getTime() - new Date(a.issue_date).getTime()));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleIssueBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBook || !selectedMember) return;
    
    setLoading(true);
    setError(null);
    
    try {
      await libraryService.issueBook(selectedBook, selectedMember);
      setSelectedBook('');
      setSelectedMember('');
      await loadData(); // Refresh all data
    } catch (err: any) {
      setError(err.message || "Failed to issue book");
    } finally {
      setLoading(false);
    }
  };

  const handleReturnBook = async (transactionId: string) => {
    try {
      await libraryService.returnBook(transactionId);
      await loadData();
    } catch (err: any) {
      alert(err.message || "Failed to return book");
    }
  };

  // Filter only active loans for the table, or show all with status
  const activeLoans = transactions.filter(t => t.status === TransactionStatus.Issued);

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col md:flex-row gap-6">
      {/* Left Panel: Issue Book Form */}
      <div className="w-full md:w-1/3 bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex flex-col">
        <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <ArrowRightLeft className="w-5 h-5 text-indigo-600" />
          Issue Book
        </h2>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        <form onSubmit={handleIssueBook} className="space-y-6 flex-1">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Member</label>
            <select 
              required
              className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white"
              value={selectedMember}
              onChange={e => setSelectedMember(e.target.value)}
            >
              <option value="">-- Choose Member --</option>
              {members.map(m => (
                <option key={m._id} value={m._id}>{m.name} ({m.email})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Book</label>
            <select 
              required
              className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white"
              value={selectedBook}
              onChange={e => setSelectedBook(e.target.value)}
            >
              <option value="">-- Choose Book --</option>
              {books.map(b => (
                <option key={b._id} value={b._id} disabled={b.available_quantity === 0}>
                  {b.title} (Qty: {b.available_quantity}) {b.available_quantity === 0 ? '- Out of Stock' : ''}
                </option>
              ))}
            </select>
          </div>

          <button 
            type="submit" 
            disabled={loading || !selectedBook || !selectedMember}
            className="w-full py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? 'Processing...' : 'Issue Book'}
          </button>
        </form>
        
        <div className="mt-6 p-4 bg-gray-50 rounded-lg text-xs text-gray-500">
          <p>Note: issuing a book will immediately decrease the available stock. Make sure to verify member identity before issuing.</p>
        </div>
      </div>

      {/* Right Panel: Active Loans */}
      <div className="w-full md:w-2/3 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col overflow-hidden">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-800">Active Loans</h2>
          <span className="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-semibold">
            {activeLoans.length} Active
          </span>
        </div>
        
        <div className="flex-1 overflow-auto p-0">
          <table className="w-full text-sm text-left text-gray-600">
            <thead className="bg-gray-100 text-gray-700 uppercase text-xs font-semibold sticky top-0">
              <tr>
                <th className="px-6 py-3">Transaction ID</th>
                <th className="px-6 py-3">Book Title</th>
                <th className="px-6 py-3">Member</th>
                <th className="px-6 py-3">Issue Date</th>
                <th className="px-6 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {activeLoans.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-400">
                    No books currently issued.
                  </td>
                </tr>
              ) : (
                activeLoans.map((t) => (
                  <tr key={t._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-mono text-xs">{t._id}</td>
                    <td className="px-6 py-4 font-medium text-gray-900">{t.book_details?.title || 'Unknown Book'}</td>
                    <td className="px-6 py-4">{t.member_details?.name || 'Unknown Member'}</td>
                    <td className="px-6 py-4 text-xs">
                      {new Date(t.issue_date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleReturnBook(t._id)}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-white border border-green-500 text-green-600 rounded hover:bg-green-50 text-xs font-medium transition-colors"
                      >
                        <CheckCircle className="w-3 h-3" />
                        Return
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};